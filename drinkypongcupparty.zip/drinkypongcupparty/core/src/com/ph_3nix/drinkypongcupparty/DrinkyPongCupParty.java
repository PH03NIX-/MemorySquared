package com.ph_3nix.drinkypongcupparty;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.OrthographicCamera;

import com.ph_3nix.drinkypongcupparty.buttons.Menu;
import com.ph_3nix.drinkypongcupparty.gameplay.Gameplay;
import com.ph_3nix.drinkypongcupparty.gameplay.Scoreboard;
import com.ph_3nix.drinkypongcupparty.levels.LevelSelection;

import java.util.ArrayList;

public class DrinkyPongCupParty extends ApplicationAdapter {
	SpriteBatch batch;
	Texture menuBackground, selected, unselected, memoryTexture, squaredTexture, audio, audio_no;
	OrthographicCamera camera;

	ArrayList<Menu> mainMenu;
	Scoreboard scoreboard;
	LevelSelection levelSelection;
	Gameplay gameplay;

	int volume, assetCount;
	float squaredY, lastDeltaX, lastDeltaY;
	boolean squaredDown;
	long levelNum;
	boolean isGameplay;

	private void loadAssets() {
		menuBackground = new Texture("menu-color.png");
		/*selected = new Texture("easy.png");
		unselected = new Texture("hard.png");
		audio = new Texture("audio.png");
		audio_no = new Texture("audio_no.png");*/

		mainMenu = new ArrayList<Menu>();
		scoreboard = new Scoreboard();
		scoreboard.newScoreboard(Gdx.graphics.getWidth(), Gdx.graphics.getHeight() / 12 * 6 /*- (Gdx.graphics.getHeight()/6/6)*//*, gamemode+gametype*/);

		mainMenu.add(new Menu(Gdx.graphics.getWidth(), Gdx.graphics.getHeight()/2 /3, 1, 0.0833333f, 0.0833333f, "play", scoreboard.getFontGenerator(), true, false, 1));

	}

	@Override
	public void create () {
		camera = new OrthographicCamera();
		camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
		camera.update();
		batch = new SpriteBatch();

		levelSelection = new LevelSelection();
		gameplay = new Gameplay();

		/*memoryTexture = new Texture("memory_text.png");
		squaredTexture = new Texture("squared_text.png");*/
		levelNum = 0;
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 1, 1, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();

		if( assetCount < 2 ) {
			//batch.draw(memoryTexture, 0, Gdx.graphics.getHeight()*  0.75f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()*0.1666666666f);
			//batch.draw(squaredTexture, 0, squaredY, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()*0.1666666666f);
			if(assetCount == 1)
				loadAssets();
			assetCount++;
		}
		else {
			if( levelNum == 0 ) {
				gameMenuLogic();
			}
			else {
				levelSelection.drawLevelSelections( batch, levelNum, camera);
			}
		}
		camera.update();

		batch.end();
	}

	/*************************************************************************************************/
	/*************************		main game-loop logic functions		******************************/
	void gotoLevelSelect() {
		levelNum = 5; //placeholder update to saved max
		levelSelection.createLevelSelection( levelNum, gameplay );
	}

	public void gameMenuLogic() {
		batch.draw(menuBackground, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()*0.5f);
		/*batch.draw(memoryTexture, 0, Gdx.graphics.getHeight()* 0.75f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()*0.1666666666f);
		batch.draw(squaredTexture, 0, squaredY, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()*0.1666666666f);*/

		// game menu "squared" png placement logic
		/*if(squaredDown) {
			if(squaredY < Gdx.graphics.getHeight()*0.52f) {
				squaredDown = false;
				squaredY += (60*Gdx.graphics.getDeltaTime() > 1.3f ? 1.3f : 60*Gdx.graphics.getDeltaTime());
			}
			else {
				squaredY -= (60*Gdx.graphics.getDeltaTime() > 1.3f ? 1.3f : 60*Gdx.graphics.getDeltaTime());
			}
		}
		else {
			if(squaredY > Gdx.graphics.getHeight()*0.666666667f) {
				squaredDown = true;
				squaredY -= (60*Gdx.graphics.getDeltaTime() > 1.3f ? 1.3f : 60*Gdx.graphics.getDeltaTime());
			}
			else {
				squaredY += (60*Gdx.graphics.getDeltaTime() > 1.3f ? 1.3f : 60*Gdx.graphics.getDeltaTime());
			}
		}*/

		for (Menu menu : mainMenu) {
			menu.drawButton(batch);
		}
		//scoreboard.drawHighScore(batch);
		float theX = Gdx.input.getX();
		float theY = Gdx.graphics.getHeight() - Gdx.input.getY();
		if (Gdx.input.justTouched()) {
			for (Menu menuButton : mainMenu) {
				if (theX > menuButton.getX1() && theX < menuButton.getX2() && theY > menuButton.getY1() && theY < menuButton.getY2()) {
					switch (menuButton.getId()) {
						case 1 :
							gotoLevelSelect();
							break;
						/*case 4 :
							Gdx.net.openURI("https://www.amazon.com/s/ref=bl_dp_s_web_0?ie=UTF8&search-alias=aps&field-brandtextbin=pH03+Games&node=2350149011");
							break;*/
					}
				}
			}
		}
	}



	
	@Override
	public void dispose () {
		batch.dispose();
		scoreboard.dispose();
		for (Menu menu : mainMenu) {
			menu.dispose();
		}
		menuBackground.dispose();
		selected.dispose();
		unselected.dispose();
		audio.dispose();
		audio_no.dispose();
		memoryTexture.dispose();
		squaredTexture.dispose();
	}
}
